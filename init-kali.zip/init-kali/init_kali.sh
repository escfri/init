#!/bin/bash
set -uex

sudo timedatectl set-timezone "Europe/Berlin"
sed -i -e"s/bindkey ^P toggle_oneline_prompt//" $HOME/.zshrc

XFCE_TARGET="$XDG_CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/"
cp xfce4-keyboard-shortcuts.xml "$XFCE_TARGET"
cp keyboard-layout.xml "$XFCE_TARGET"

cp qterminal.ini $XDG_CONFIG_HOME/qterminal.org/

#!/bin/bash
set -uex

NAME="user"
EMAIL="user@example.com"

sudo apt -y update &&
  sudo apt -y install neovim tmux rustup build-essential ripgrep curl fzf pipx &&
  sudo apt -y remove nano

if [ ! -f "$HOME/.ssh/id_ed25519" ]; then
  ssh-keygen -t ed25519 -a 100
fi

git config --global init.defaultBranch master
git config --global user.email "$EMAIL"
git config --global user.name "$NAME"

# install nerd font
wget https://github.com/ryanoasis/nerd-fonts/releases/download/v3.3.0/UbuntuMono.zip -O /tmp/UbuntuMono.zip
unzip /tmp/UbuntuMono.zip -d /tmp/UbuntuMono/
mkdir -p ~/.local/share/fonts/
cp /tmp/UbuntuMono/*.ttf ~/.local/share/fonts/
fc-cache
rm -rf /tmp/UbuntuMono/

cp tmux.conf ~/.tmux.conf
cp -r lazyvim ~/.config/nvim

sudo timedatectl set-timezone "Europe/Berlin"
sed -i -e"s/bindkey ^P toggle_oneline_prompt//" $HOME/.zshrc

XFCE_TARGET="$XDG_CONFIG_HOME/xfce4/xfconf/xfce-perchannel-xml/"
cp xfce4-keyboard-shortcuts.xml "$XFCE_TARGET"
cp keyboard-layout.xml "$XFCE_TARGET"

cp qterminal.ini $XDG_CONFIG_HOME/qterminal.org/

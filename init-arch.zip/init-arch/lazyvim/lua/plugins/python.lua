return {
  "neovim/nvim-lspconfig",
  opts = {
    servers = {
      basedpyright = {
        settings = {
          basedpyright = {
            analysis = {
              diagnosticMode = "openFilesOnly",
              typeCheckingMode = "standard",
              inlayHints = {
                callArgumentNames = true,
              },
            },
          },
        },
      },
    },
  },
}

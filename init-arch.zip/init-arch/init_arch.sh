#!/bin/bash

set -e

NAME="user"
EMAIL="user@example.com"

sudo pacman -Suy
LAZYVIM_DEPS="neovim git ripgrep curl fzf fd ttf-ubuntu-mono-nerd base-devel"
sudo pacman -S vim tmux rustup $LAZYVIM_DEPS

if [ ! -f "$HOME/.ssh/id_ed25519" ]; then
  ssh-keygen -t ed25519 -a 100
fi

git config --global init.defaultBranch master
git config --global user.email "$EMAIL"
git config --global user.name "$NAME"

cp tmux.conf ~/.tmux.conf
ln -s lazyvim ~/.config/nvim/

sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"
sed -i -e 's/^plugins=(\(.*\))/plugins=(\1 fzf)/' ~/.zshrc

# setup workspaces
gsettings set org.gnome.mutter dynamic-workspaces 'false'
gsettings set org.gnome.desktop.wm.preferences num-workspaces '4'

# change keybinds
gsettings set org.gnome.desktop.wm.keybindings switch-to-workspace-1 "['<Alt>F1']"
gsettings set org.gnome.desktop.wm.keybindings switch-to-workspace-2 "['<Alt>F2']"
gsettings set org.gnome.desktop.wm.keybindings switch-to-workspace-3 "['<Alt>F3']"
gsettings set org.gnome.desktop.wm.keybindings switch-to-workspace-4 "['<Alt>F4']"

gsettings set org.gnome.desktop.wm.keybindings move-to-workspace-1 "['<Super><Shift>Home','<Primary>F1']"
gsettings set org.gnome.desktop.wm.keybindings move-to-workspace-2 "['<Primary>F2']"
gsettings set org.gnome.desktop.wm.keybindings move-to-workspace-3 "['<Primary>F3']"
gsettings set org.gnome.desktop.wm.keybindings move-to-workspace-4 "['<Primary>F4']"

# gsettings set org.gnome.settings-daemon.plugins.media-keys terminal "[]" # default Alt+F1
gsettings set org.gnome.desktop.wm.keybindings panel-run-dialog "[]" # default Alt+F2
gsettings set org.gnome.desktop.wm.keybindings close "[]"            # default Alt+F4
gsettings set org.gnome.desktop.wm.keybindings toggle-maximized "['<Alt>F10','<Alt>Return']"

gsettings set org.gnome.Console audible-bell 'false'
gsettings set org.gnome.Console visual-bell 'false'
gsettings set org.gnome.Console custom-font 'UbuntuMono Nerd Font Mono 10'
gsettings set org.gnome.Console transparency 'true'

# general setup
gsettings set org.gnome.desktop.session idle-delay '0'
gsettings set org.gnome.desktop.interface gtk-theme 'Yaru-dark'
gsettings set org.gnome.desktop.interface color-scheme 'prefer-dark'
